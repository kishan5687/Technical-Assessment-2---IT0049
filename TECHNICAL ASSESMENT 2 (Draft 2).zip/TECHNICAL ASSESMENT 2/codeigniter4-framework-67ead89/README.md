# Point of Sale (POS) Application - Technical Assessment 2

A lightweight web application built using **CodeIgniter 4** and **MySQL**. This project demonstrates database integration using CodeIgniter's native Model-View-Controller (MVC) architecture and Query Builder services, extending the static array features built during TFA1.

## 🚀 Features
- **Real MySQL Database Integration:** Replaced all hardcoded array collections with dynamic relational storage.
- **Query Builder Execution:** Data manipulation utilizes secure query building mechanisms over raw SQL strings.
- **Clean MVC Architecture:** Clean separation of programmatic layers matching production framework criteria.

---

## 🛠️ Prerequisites & Installation Setup

Follow these operational steps to deploy and execute the repository locally:

### 1. Clone or Extract the Project
Ensure the project structure is placed in your development directory:
```bash
# If using terminal:
cd C:\xampp\htdocs\
```
*(Ensure your folder contains the critical `app`, `public`, `system`, and `writable` directories).*

### 2. Database Environment Provisioning
1. Launch the **XAMPP Control Panel** and execute the **Apache** and **MySQL** modules.
2. Navigate to your local server gateway: `http://localhost/phpmyadmin/`
3. Generate a clean database instance named exactly: **`pos_database`**
4. Open the **SQL** tab execution terminal, copy-paste the structural schema below, and click **Go**:

```sql
CREATE TABLE customers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(100) NOT NULL,
 email VARCHAR(100) NOT NULL,
 phone VARCHAR(20),
 created_at DATETIME NOT NULL
);

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 full_name VARCHAR(100) NOT NULL,
 created_at DATETIME NOT NULL
);

-- Mock Data Injection
INSERT INTO customers (full_name, email, phone, created_at) VALUES 
('Juan Dela Cruz', 'juan@email.com', '09123456789', NOW()),
('Raina Quejada', 'raina@email.com', '09456789012', NOW()),
('Vikki Santiago', 'vikki@email.com', '09234567890', NOW()),
('Jem Mercado', 'jem@email.com', '09345678901', NOW()),
('Raina Quejada', 'raina@email.com', '09456789012', NOW());

INSERT INTO users (username, full_name, created_at) VALUES 
('admin_juan', 'Juan Dela Cruz', NOW()),
('raina_k', 'Raina Quejada', NOW()),
('santiago_v', 'Vikki Santiago', NOW()),
('mercado_j', 'Jem Mercado', NOW()),
('raina_k2', 'Raina Quejada', NOW());


### 3. Application Configuration Setup
1. Look at the root layout folder and locate the **`.env`** file.
2. Verify that your environment variables match your XAMPP default parameters:

```env
CI_ENVIRONMENT = development

database.default.hostname = localhost
database.default.database = pos_database
database.default.username = root
database.default.password = 
database.default.DBDriver = MySQLi
database.default.port = 3306
```

---

## ⚡ Execution Instructions

1. Launch your preferred command line terminal or the built-in **VS Code Terminal**.
2. Run the framework's optimization server command directly:
   ```bash
   C:\xampp\php\php spark serve
   ```
3. Open your web browser tool and load the target operational views:
   - **Customer Directory Grid:** `http://localhost:8080/customers`
   - **User System Accounts:** `http://localhost:8080/users`
