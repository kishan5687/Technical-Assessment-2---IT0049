<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $allowedFields    = ['username', 'full_name', 'created_at'];

    public function getAllUsers()
    {
        return $this->builder()->get()->getResultArray();
    }
}
