<?php
namespace App\Controllers;
use App\Models\CustomerModel;

class CustomerController extends BaseController {
    public function index() {
        $model = new CustomerModel();
        $data['customers'] = $model->getAllCustomers();
        return view('customer_accounts', $data); // Passes array to view
    }
}
