<!DOCTYPE html>
<html>
<head><title>Customers</title></head>
<body>
    <h2>Customer Accounts</h2>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Phone</th>
        </tr>
        <?php foreach ($customers as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['full_name'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['phone'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
