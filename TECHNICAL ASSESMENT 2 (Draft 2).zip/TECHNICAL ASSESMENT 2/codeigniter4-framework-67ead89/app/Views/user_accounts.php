<!DOCTYPE html>
<html>
<head><title>Users</title></head>
<body>
    <h2>User Accounts</h2>
    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>Username</th><th>Full Name</th>
        </tr>
        <?php foreach ($users as $row): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['username'] ?></td>
            <td><?= $row['full_name'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
